#sudo python3 lightSensor_0.py
import math
import sys
import time
import os
import datetime
import csv
import pathlib
import keyboard
from grove.adc import ADC
 
currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
from export import Export

class GroveLightSensor:
 
    def __init__(self, channel):
        self.channel = channel
        self.adc = ADC()
 
    @property
    def light(self):
        value = self.adc.read(self.channel)
        return value
 
Grove = GroveLightSensor
interval = 500
Export = Export(os.path.splitext(os.path.basename(__file__))[0]
                , interval
                , datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d_%H:%M:%S'))
 
def main():
    if len(sys.argv) < 2:
        print('Use default Analog port: 0.')
        sensor = GroveLightSensor(0)
    #    print('Usage: {} adc_channel'.format(sys.argv[0]))
    #    sys.exit(1)
    else:
        sensor = GroveLightSensor(int(sys.argv[1]))
 
    print('Detecting light...(Press \'q\' to quite)')
    count = 0
    while True:
        if keyboard.is_pressed("q"):
            break
        print('Light value: {0}'.format(sensor.light))
        count+=1
    	Export.writeCsv(count, sensor.light)
        time.sleep(interval/1000)
    
    binInterval = input("Input binInterval(ex: 10, 100): ")
    Export.writeCountCsv(binInterval)
if __name__ == '__main__':
    main()
