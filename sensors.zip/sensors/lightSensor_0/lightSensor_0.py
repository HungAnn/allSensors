import math
import sys
import time
import os
from grove.adc import ADC
 
 
class GroveLightSensor:
 
    def __init__(self, channel):
        self.channel = channel
        self.adc = ADC()
 
    @property
    def light(self):
        value = self.adc.read(self.channel)
        return value
 
Grove = GroveLightSensor
home = os.path.expanduser("~")
sensorName = __file__.split('.')[0]
cache = os.path.join(home, 'SensorPlugin_C', sensorName, 'cache')
csvName = os.path.join(cache, datetime.datetime.now()+'.csv')
 
def main():
    if len(sys.argv) < 2:
        print('Use default Analog port: 0.')
        sensor = GroveLightSensor(0)
    #    print('Usage: {} adc_channel'.format(sys.argv[0]))
    #    sys.exit(1)
    else:
        sensor = GroveLightSensor(int(sys.argv[1]))
 
    print('Detecting light...')
    with open(csvName, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        while True:
            print('Light value: {0}'.format(sensor.light))
            writer.writerow([sensor.light])
            time.sleep(1)
 
if __name__ == '__main__':
    main()